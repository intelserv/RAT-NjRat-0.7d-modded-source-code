﻿Imports System

Public NotInheritable Class GClass4
    ' Methods
    Public Sub New(ByVal string_2 As String, ByVal string_3 As String)
        Me.string_0 = string_2
        Me.string_1 = string_3
    End Sub

    Public Function method_0() As String
        Return Me.string_0
    End Function

    Public Function method_1() As String
        Return Me.string_1
    End Function


    ' Fields
    Private string_0 As String
    Private string_1 As String
End Class



